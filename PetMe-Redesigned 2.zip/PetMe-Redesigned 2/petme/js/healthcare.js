// ==========================================================================
// Healthcare page — appointment type chips + booking form + clinic map
// ==========================================================================

(function () {
  const chips = document.getElementById("visit-type-chips");
  let visitType = "Checkup";

  chips.querySelectorAll(".chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      chips.querySelectorAll(".chip").forEach((c) => c.classList.remove("active"));
      chip.classList.add("active");
      visitType = chip.dataset.type;
    });
  });

  // Service cards up top jump to the booking form with the matching visit type preselected
  document.querySelectorAll(".feature-card[data-visit-type]").forEach((card) => {
    card.addEventListener("click", () => {
      const target = card.dataset.visitType;
      const matchingChip = chips.querySelector(`.chip[data-type="${target}"]`);
      if (matchingChip) matchingChip.click();
    });
  });

  const form = document.getElementById("healthcare-form");
  const banner = document.getElementById("healthcare-banner");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const checks = [
      validateField(document.getElementById("hc-pet-name"), isNotEmpty),
      validateField(document.getElementById("hc-species"), isNotEmpty),
      validateField(document.getElementById("hc-clinic"), isNotEmpty),
      validateField(document.getElementById("hc-date"), isNotEmpty),
      validateField(document.getElementById("hc-notes"), isNotEmpty),
      validateField(document.getElementById("hc-owner-name"), isNotEmpty),
      validateField(document.getElementById("hc-phone"), isPhone),
      validateField(document.getElementById("hc-email"), isEmail),
    ];

    if (checks.includes(false)) {
      showBanner(banner, "error", "A few details still need attention before we can book this visit.");
      return;
    }

    const petName = document.getElementById("hc-pet-name").value.trim();
    const clinic = document.getElementById("hc-clinic").value;
    const urgentNote =
      visitType === "Emergency"
        ? " This has been flagged urgent — expect a call within minutes."
        : ` We'll confirm the slot at ${clinic} by email shortly.`;

    showBanner(banner, "success", `${visitType} request received for ${petName}.` + urgentNote);
    form.querySelector("button[type='submit']").disabled = true;
  });

  /* ---------------- Clinic locator map ---------------- */
  function directionsUrl(address) {
    return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address)}`;
  }
  function embedUrl(address) {
    return `https://maps.google.com/maps?q=${encodeURIComponent(address)}&t=&z=14&ie=UTF8&iwloc=&output=embed`;
  }

  // "Get directions" links on each clinic card
  document.querySelectorAll(".clinic-card[data-address]").forEach((card) => {
    const link = card.querySelector(".clinic-directions");
    if (link) link.href = directionsUrl(card.dataset.address);
  });

  // Interactive map + picker list
  const mapFrame = document.getElementById("clinic-map-frame");
  const mapDirectionsBtn = document.getElementById("map-directions-btn");
  const pickerItems = document.querySelectorAll(".map-picker-item");

  function selectClinic(item) {
    pickerItems.forEach((el) => {
      el.classList.remove("active");
      el.setAttribute("aria-selected", "false");
    });
    item.classList.add("active");
    item.setAttribute("aria-selected", "true");
    const address = item.dataset.address;
    mapFrame.src = embedUrl(address);
    mapDirectionsBtn.href = directionsUrl(address);
  }

  if (pickerItems.length && mapFrame) {
    pickerItems.forEach((item) => {
      item.addEventListener("click", () => selectClinic(item));
    });
    // initialise with the first (active) clinic
    selectClinic(document.querySelector(".map-picker-item.active") || pickerItems[0]);
  }
})();

