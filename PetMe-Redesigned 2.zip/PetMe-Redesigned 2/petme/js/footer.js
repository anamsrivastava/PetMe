document.addEventListener("DOMContentLoaded", () => {
  const mount = document.getElementById("site-footer-include");
  if (!mount) return;

  mount.innerHTML = `
    <div class="container">
      <div class="footer-grid">
        <div class="footer-col">
          <div class="footer-brand">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <circle cx="12" cy="12" r="11" fill="#F2EFE4" fill-opacity="0.12"/>
              <path d="M12 13.6c-2.1 0-4.4 1.7-4.4 3.6 0 .9.7 1.4 1.6 1.4.8 0 1.4-.4 2.8-.4s2 .4 2.8.4c.9 0 1.6-.5 1.6-1.4 0-1.9-2.3-3.6-4.4-3.6Z" fill="#F59E0B"/>
              <ellipse cx="7.6" cy="9.2" rx="1.5" ry="1.9" fill="#F59E0B"/>
              <ellipse cx="16.4" cy="9.2" rx="1.5" ry="1.9" fill="#F59E0B"/>
              <ellipse cx="10.4" cy="6.6" rx="1.3" ry="1.7" fill="#F59E0B"/>
              <ellipse cx="13.6" cy="6.6" rx="1.3" ry="1.7" fill="#F59E0B"/>
            </svg>
            PetMe
          </div>
          <p>A working record of animals who need homes, and the people ready to show up for them — with healthcare at the centre of every placement.</p>
          <form class="footer-newsletter" data-newsletter-form>
            <input type="email" placeholder="you@email.com" aria-label="Email address for newsletter" required />
            <button type="submit" class="btn btn-accent" style="padding:10px 18px; font-size:13.5px;">Join</button>
          </form>
          <p class="muted" style="font-size:12.5px; margin-top:8px; color:rgba(242,239,228,0.7);" data-newsletter-feedback></p>
        </div>
        <div class="footer-col">
          <h5>Get involved</h5>
          <a href="adopt.html">Adopt a pet</a>
          <a href="donate.html">Donate</a>
          <a href="healthcare.html">Pet healthcare</a>
          <a href="volunteer.html">Volunteer</a>
          <a href="sos-report.html">Report a stray</a>
          <a href="foster.html">Become a foster</a>
        </div>
        <div class="footer-col">
          <h5>Resources</h5>
          <a href="faq.html">Adoption FAQ</a>
          <a href="foster.html">Foster guide</a>
          <a href="healthcare.html#clinics">Partner clinics</a>
          <a href="suggestions.html">Suggestions</a>
          <a href="contact.html">Contact us</a>
          <a href="about.html">About &amp; founders</a>
          <a href="register.html">Create account</a>
        </div>
        <div class="footer-col">
          <h5>Stay close</h5>
          <p style="margin-bottom:10px;">Ghaziabad · Delhi NCR · Noida</p>
          <p style="margin-bottom:10px;">Emergency line: <a href="tel:18007384357" style="color:var(--marigold);">1800-PET-HELP</a></p>
          <p style="margin-bottom:14px; font-size:13px;">Founders: Anam Srivastava · Anish Das · Astha Tyagi</p>
          <div class="footer-socials">
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="PetMe on Instagram"><svg viewBox="0 0 24 24" fill="none" stroke="#F2EFE4" stroke-width="1.6"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r="1"/></svg></a>
            <a href="https://x.com" target="_blank" rel="noopener noreferrer" aria-label="PetMe on X"><svg viewBox="0 0 24 24" fill="none" stroke="#F2EFE4" stroke-width="1.6"><path d="M4 4l16 16M20 4 4 20"/></svg></a>
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="PetMe on Facebook"><svg viewBox="0 0 24 24" fill="none" stroke="#F2EFE4" stroke-width="1.6"><path d="M15 4h-2a4 4 0 0 0-4 4v3H7v4h2v7h4v-7h3l1-4h-4V8a1 1 0 0 1 1-1h3V4Z"/></svg></a>
          </div>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© <span data-year></span> PetMe. Built for animals who are still waiting.</span>
        <span>Bringing hearts and paws together · Healthcare-first placement.</span>
      </div>
    </div>
  `;
  initFooterYear();
  initNewsletterForm();
});
