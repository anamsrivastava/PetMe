// PetMe API helper. The Flask backend serves the site and exposes /api/*.
const PETME_API = window.PETME_API_URL || "";

async function petmeApi(path, payload) {
  try {
    const response = await fetch(`${PETME_API}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload || {})
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "Request failed");
    return data;
  } catch (error) {
    console.warn("PetMe backend unavailable:", error.message);
    return { ok: false, offline: true, error: error.message };
  }
}
