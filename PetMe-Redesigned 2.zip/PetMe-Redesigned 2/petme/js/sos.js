// ==========================================================================
// SOS Report page
// ==========================================================================

(function () {
  const chips = document.getElementById("urgency-chips");
  let urgency = "Stray, appears okay";
  chips.querySelectorAll(".chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      chips.querySelectorAll(".chip").forEach((c) => c.classList.remove("active"));
      chip.classList.add("active");
      urgency = chip.dataset.urgency;
    });
  });

  const description = document.getElementById("sos-description");
  const charCount = document.getElementById("char-count");
  description.addEventListener("input", () => {
    charCount.textContent = description.value.length;
  });

  const form = document.getElementById("sos-form");
  const banner = document.getElementById("sos-banner");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const checks = [
      validateField(document.getElementById("sos-species"), isNotEmpty),
      validateField(document.getElementById("sos-location"), isNotEmpty),
      validateField(document.getElementById("sos-description"), isNotEmpty),
      validateField(document.getElementById("sos-name"), isNotEmpty),
      validateField(document.getElementById("sos-phone"), isPhone),
    ];
    if (checks.includes(false)) {
      showBanner(banner, "error", "A few fields still need details before this report can be routed.");
      return;
    }
    const urgencyNote =
      urgency === "In immediate danger"
        ? " This has been flagged urgent and a coordinator will call within minutes."
        : " A coordinator will follow up shortly.";
    const photo = document.getElementById("sos-photo");
    const result = await petmeApi("/api/sos", {
      name: document.getElementById("sos-name").value.trim(),
      phone: document.getElementById("sos-phone").value.trim(),
      location: document.getElementById("sos-location").value.trim(),
      species: document.getElementById("sos-species").value.trim(),
      urgency, description: document.getElementById("sos-description").value.trim(),
      photoUrl: photo && photo.files && photo.files[0] ? photo.files[0].name : ""
    });
    showBanner(banner, "success", (result.ok ? "Report saved. " : "Report captured. ") + urgencyNote);
    form.querySelector("button[type='submit']").disabled = true;
  });
})();
