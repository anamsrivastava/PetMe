// ==========================================================================
// Adopt page — filtering, search, and the detail modal
// ==========================================================================

(function () {
  const grid = document.getElementById("pet-grid");
  const emptyState = document.getElementById("empty-state");
  const resultsCount = document.getElementById("results-count");
  const searchInput = document.getElementById("pet-search");

  const state = { species: "all", age: "all", query: "", shortlistOnly: false };

  function matches(pet) {
    const q = state.query.trim().toLowerCase();
    const matchesQuery = !q || pet.name.toLowerCase().includes(q) || pet.breed.toLowerCase().includes(q);
    const favOk = !state.shortlistOnly || (typeof isFavorite === "function" && isFavorite(pet.id));
    return (
      (state.species === "all" || pet.species === state.species) &&
      (state.age === "all" || pet.ageGroup === state.age) &&
      matchesQuery &&
      favOk
    );
  }

  function render() {
    const results = PETS.filter(matches);
    grid.innerHTML = results.map(renderTagCard).join("");
    emptyState.style.display = results.length ? "none" : "block";
    const base = `${results.length} animal${results.length === 1 ? "" : "s"} on file`;
    resultsCount.textContent = state.shortlistOnly ? base + " · shortlist" : base;

    grid.querySelectorAll(".tag-card").forEach((card) => {
      card.addEventListener("click", (e) => {
        if (e.target.closest(".fav-btn")) return;
        e.preventDefault();
        openModal(card.dataset.petId);
      });
    });
    if (typeof initFavoriteButtons === "function") initFavoriteButtons(grid);
  }

  const shortlistBtn = document.getElementById("shortlist-filter");
  if (shortlistBtn) {
    shortlistBtn.addEventListener("click", () => {
      state.shortlistOnly = !state.shortlistOnly;
      shortlistBtn.classList.toggle("active", state.shortlistOnly);
      render();
    });
  }

  function setupChipGroup(selector, key) {
    document.querySelectorAll(selector).forEach((chip) => {
      chip.addEventListener("click", () => {
        document.querySelectorAll(selector).forEach((c) => c.classList.remove("active"));
        chip.classList.add("active");
        state[key] = chip.dataset[key];
        render();
      });
    });
  }

  setupChipGroup("[data-species]", "species");
  setupChipGroup("[data-age]", "age");

  searchInput.addEventListener("input", (e) => {
    state.query = e.target.value;
    render();
  });

  /* ---------------- Modal ---------------- */
  const modal = document.getElementById("pet-modal");
  const modalImg = document.getElementById("modal-img");
  const modalName = document.getElementById("modal-pet-name");
  const modalId = document.getElementById("modal-id");
  const modalMeta = document.getElementById("modal-meta");
  const modalBlurb = document.getElementById("modal-blurb");
  const adoptForm = document.getElementById("adopt-form");
  const adoptBanner = document.getElementById("adopt-banner");
  let currentPet = null;

  function openModal(id) {
    const pet = PETS.find((p) => p.id === id);
    if (!pet) return;
    currentPet = pet;
    modalImg.onerror = function () {
      this.onerror = null;
      if (typeof PET_IMAGE_FALLBACK !== "undefined") this.src = PET_IMAGE_FALLBACK;
    };
    modalImg.src = pet.image;
    modalImg.alt = pet.name;
    modalName.textContent = pet.name;
    modalId.textContent = `${pet.id} · ${pet.location}`;
    modalMeta.textContent = `${pet.species} · ${pet.breed} · ${pet.age} · ${pet.size} · ${pet.gender}`;
    modalBlurb.textContent = pet.blurb;
    adoptForm.reset();
    adoptBanner.className = "form-banner";
    adoptForm.querySelectorAll(".field").forEach((f) => f.classList.remove("invalid"));
    modal.classList.add("open");
    document.body.style.overflow = "hidden";
    history.replaceState(null, "", `#${pet.id}`);
  }

  function closeModal() {
    modal.classList.remove("open");
    document.body.style.overflow = "";
    history.replaceState(null, "", window.location.pathname);
  }

  document.getElementById("modal-close").addEventListener("click", closeModal);
  modal.addEventListener("click", (e) => { if (e.target === modal) closeModal(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && modal.classList.contains("open")) closeModal(); });

  adoptForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const nameOk = validateField(document.getElementById("adopter-name"), isNotEmpty);
    const emailOk = validateField(document.getElementById("adopter-email"), isEmail);
    const phoneOk = validateField(document.getElementById("adopter-phone"), isPhone);

    if (!(nameOk && emailOk && phoneOk)) {
      showBanner(adoptBanner, "error", "A few details need a second look before we can submit this.");
      return;
    }
    const payload = {
      petId: currentPet.id,
      petName: currentPet.name,
      name: document.getElementById("adopter-name").value.trim(),
      email: document.getElementById("adopter-email").value.trim(),
      phone: document.getElementById("adopter-phone").value.trim()
    };
    const apiResult = typeof petmeApi === "function" ? await petmeApi("/api/adoptions", payload) : { ok: false, offline: true };
    showBanner(adoptBanner, apiResult.ok ? "success" : "success", apiResult.ok
      ? `Inquiry saved — our team will reach out about ${currentPet.name} within one business day.`
      : `Inquiry captured on this device — our team will reach out about ${currentPet.name} within one business day.`);
    adoptForm.querySelector("button[type='submit']").disabled = true;
  });

  // Deep link support: adopt.html#PM-0231 opens that pet directly
  render();
  const hashId = window.location.hash.replace("#", "");
  if (hashId) openModal(hashId);
})();
