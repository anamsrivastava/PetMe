// ==========================================================================
// Volunteer page — role selection + signup form
// ==========================================================================

(function () {
  const roleCards = document.querySelectorAll(".role-card");
  const summary = document.getElementById("selected-roles-summary");
  const rolesErrorField = document.getElementById("roles-error").closest(".field");
  const selected = new Set();

  function toggleRole(card) {
    const role = card.dataset.role;
    const isSelected = selected.has(role);
    if (isSelected) {
      selected.delete(role);
    } else {
      selected.add(role);
    }
    card.classList.toggle("selected", !isSelected);
    card.setAttribute("aria-checked", String(!isSelected));
    updateSummary();
  }

  function updateSummary() {
    if (selected.size === 0) {
      summary.textContent = "No roles selected yet — tap a card above.";
      return;
    }
    summary.textContent = Array.from(selected).join(", ");
    rolesErrorField.classList.remove("invalid");
  }

  roleCards.forEach((card) => {
    card.addEventListener("click", () => toggleRole(card));
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        toggleRole(card);
      }
    });
  });

  const form = document.getElementById("volunteer-form");
  const banner = document.getElementById("volunteer-banner");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const checks = [
      validateField(document.getElementById("vol-name"), isNotEmpty),
      validateField(document.getElementById("vol-age"), (v) => parseInt(v, 10) >= 16),
      validateField(document.getElementById("vol-email"), isEmail),
      validateField(document.getElementById("vol-phone"), isPhone),
      validateField(document.getElementById("vol-availability"), isNotEmpty),
    ];
    const rolesOk = selected.size > 0;
    rolesErrorField.classList.toggle("invalid", !rolesOk);

    if (checks.includes(false) || !rolesOk) {
      showBanner(banner, "error", "A few details still need attention before we can submit this.");
      return;
    }
    const result = await petmeApi("/api/volunteers", {
      name: document.getElementById("vol-name").value.trim(),
      email: document.getElementById("vol-email").value.trim(),
      phone: document.getElementById("vol-phone").value.trim(),
      age: document.getElementById("vol-age").value.trim(),
      availability: document.getElementById("vol-availability").value.trim(),
      roles: [...selected]
    });
    showBanner(banner, "success", result.ok ? `Application saved for ${selected.size} role${selected.size > 1 ? "s" : ""}.` : `Application captured for ${selected.size} role${selected.size > 1 ? "s" : ""}.`);
    form.querySelector("button[type='submit']").disabled = true;
  });
})();
