
/* ---- Page preloader ---- */
(function initPagePreloader() {
  const el = document.getElementById("page-preloader");
  const skip = document.getElementById("preloader-skip");
  if (!el) return;

  let done = false;
  const hide = () => {
    if (done) return;
    done = true;
    el.classList.add("is-done");
    if (skip) skip.classList.add("is-done");
    setTimeout(() => {
      el.remove();
      if (skip) skip.remove();
    }, 500);
  };

  if (skip) skip.addEventListener("click", hide);

  // Hide when page is ready (min display ~0.7s so animation is visible)
  const start = Date.now();
  const finish = () => {
    const wait = Math.max(0, 700 - (Date.now() - start));
    setTimeout(hide, wait);
  };

  if (document.readyState === "complete") finish();
  else window.addEventListener("load", finish);

  // Safety: never block longer than 4s
  setTimeout(hide, 4000);
})();

// ==========================================================================
// PetMe — shared behaviour across every page
// ==========================================================================

document.addEventListener("DOMContentLoaded", () => {
  initNav();
  initFooterYear();
  initLedgerCounters();
  initNewsletterForm();
  initScrollReveal();
  initHeaderScroll();
  initParallaxPaw();
});

/* ---------------- Nav ---------------- */
function initNav() {
  const toggle = document.querySelector(".nav-toggle");
  const links = document.querySelector(".nav-links");
  if (!toggle || !links) return;
  toggle.addEventListener("click", () => {
    const open = links.classList.toggle("open");
    toggle.classList.toggle("open", open);
    toggle.setAttribute("aria-expanded", String(open));
  });
  links.querySelectorAll("a").forEach((a) =>
    a.addEventListener("click", () => {
      links.classList.remove("open");
      toggle.classList.remove("open");
    })
  );
}

function initFooterYear() {
  document.querySelectorAll("[data-year]").forEach((el) => {
    el.textContent = new Date().getFullYear();
  });
}

/* ---------------- Scroll reveal (sections fade/lift in as they arrive) ---------------- */
function initScrollReveal() {
  const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (prefersReduced) return;

  const targets = document.querySelectorAll(
    "main > section, .footer-newsletter, .info-card, .feature-card"
  );
  if (!targets.length) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: "0px 0px -60px 0px" }
  );

  targets.forEach((el, i) => {
    el.classList.add("reveal");
    el.style.transitionDelay = `${Math.min(i % 4, 3) * 60}ms`;
    observer.observe(el);
  });

  // The first section (hero) should already be visible on load, not wait on scroll
  const first = document.querySelector("main > section");
  if (first) {
    requestAnimationFrame(() => first.classList.add("in-view"));
  }
}

/* ---------------- Ledger counters (animate numbers into view) ---------------- */
function initLedgerCounters() {
  const nums = document.querySelectorAll("[data-count-to]");
  if (!nums.length) return;

  const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const animate = (el) => {
    const target = parseInt(el.dataset.countTo, 10);
    const suffix = el.dataset.suffix || "";
    if (prefersReduced) {
      el.textContent = target.toLocaleString() + suffix;
      return;
    }
    const duration = 1100;
    const start = performance.now();
    const tick = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.round(eased * target).toLocaleString() + suffix;
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          animate(entry.target);
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.4 }
  );
  nums.forEach((el) => observer.observe(el));
}

/* ---------------- Tag-card renderer (used by home + adopt pages) ---------------- */
function renderTagCard(pet) {
  const fallback = typeof PET_IMAGE_FALLBACK !== "undefined" ? PET_IMAGE_FALLBACK : "";
  return `
    <a class="tag-card" href="adopt.html#${pet.id}" data-pet-id="${pet.id}" aria-label="View ${pet.name}'s profile">
      <img class="tag-photo" src="${pet.image}" alt="${pet.name}, a ${pet.age} old ${pet.breed}" loading="lazy" onerror="this.onerror=null;this.src='${fallback}'" />
      <div class="tag-body">
        <div class="tag-top-row">
          <span class="tag-name">${pet.name}</span>
          <span class="tag-id">${pet.id}</span>
        </div>
        <div class="tag-meta">${pet.species} · ${pet.breed} · ${pet.age} · ${pet.size}</div>
        <p class="tag-blurb">${pet.blurb}</p>
      </div>
    </a>`;
}

/* ---------------- Generic field validation helpers ---------------- */
function validateField(field, testFn, message) {
  const wrapper = field.closest(".field");
  const errorEl = wrapper.querySelector(".field-error");
  const valid = testFn(field.value.trim());
  wrapper.classList.toggle("invalid", !valid);
  if (errorEl && message) errorEl.textContent = message;
  return valid;
}

function isNotEmpty(v) { return v.length > 0; }
function isEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
function isPhone(v) { return /^[0-9+\-\s()]{7,}$/.test(v); }

function showBanner(banner, type, message) {
  banner.textContent = message;
  banner.className = `form-banner show ${type}`;
  banner.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

/* ---------------- Newsletter (footer, all pages) ---------------- */
function initNewsletterForm() {
  document.querySelectorAll("[data-newsletter-form]").forEach((form) => {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const input = form.querySelector("input[type='email']");
      const feedback = form.parentElement.querySelector("[data-newsletter-feedback]") || form.querySelector("[data-newsletter-feedback]");
      if (!isEmail(input.value.trim())) {
        if (feedback) feedback.textContent = "Enter a valid email to subscribe.";
        return;
      }
      if (feedback) feedback.textContent = "You're on the list — welcome in.";
      form.reset();
    });
  });
}


/* ---------------- Sticky header elevation on scroll ---------------- */
function initHeaderScroll() {
  const header = document.querySelector(".site-header");
  if (!header) return;
  const onScroll = () => {
    header.classList.toggle("is-scrolled", window.scrollY > 12);
  };
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });
}

/* ---------------- Subtle hero paw trail parallax ---------------- */
function initParallaxPaw() {
  const trail = document.querySelector(".hero-paw-trail");
  if (!trail || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  window.addEventListener(
    "scroll",
    () => {
      const y = window.scrollY;
      if (y > 400) return;
      trail.style.transform = `translateY(${y * 0.15}px)`;
      trail.style.opacity = String(Math.max(0.2, 1 - y / 350));
    },
    { passive: true }
  );
}

/* ==========================================================================
   Standout features — unique PetMe experiences (client-side only)
   ========================================================================== */

const FAV_KEY = "petme_favorites";

function getFavorites() {
  try {
    return JSON.parse(localStorage.getItem(FAV_KEY) || "[]");
  } catch {
    return [];
  }
}

function toggleFavorite(petId, btn) {
  let favs = getFavorites();
  const on = favs.includes(petId);
  if (on) favs = favs.filter((id) => id !== petId);
  else favs.push(petId);
  localStorage.setItem(FAV_KEY, JSON.stringify(favs));
  if (btn) {
    btn.classList.toggle("is-fav", !on);
    btn.setAttribute("aria-pressed", String(!on));
    btn.title = !on ? "Saved to your shortlist" : "Save to shortlist";
  }
  return !on;
}

function isFavorite(petId) {
  return getFavorites().includes(petId);
}

/** Derive short personality chips from pet data (no backend change) */
function petTraits(pet) {
  const traits = [];
  if (pet.vaccinated) traits.push("Vaccinated");
  if (pet.sterilised) traits.push("Sterilised");
  if (pet.ageGroup === "young") traits.push("Playful");
  if (pet.ageGroup === "senior") traits.push("Calm");
  if (pet.size === "Small") traits.push("Apartment-friendly");
  if (pet.size === "Large") traits.push("Needs space");
  const b = (pet.blurb || "").toLowerCase();
  if (b.includes("kid") || b.includes("children")) traits.push("Good with kids");
  if (b.includes("cat")) traits.push("Cat-friendly");
  if (b.includes("dog")) traits.push("Dog-aware");
  return traits.slice(0, 3);
}

/* Override tag-card renderer with favorites + traits */
function renderTagCard(pet) {
  const fallback = typeof PET_IMAGE_FALLBACK !== "undefined" ? PET_IMAGE_FALLBACK : "";
  const traits = petTraits(pet)
    .map((t) => `<span class="trait-chip">${t}</span>`)
    .join("");
  const fav = isFavorite(pet.id);
  return `
    <article class="tag-card" data-pet-id="${pet.id}">
      <button type="button" class="fav-btn ${fav ? "is-fav" : ""}" data-fav-id="${pet.id}"
        aria-label="Save ${pet.name} to shortlist" aria-pressed="${fav}" title="${fav ? "Saved to your shortlist" : "Save to shortlist"}">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true">
          <path d="M12 21s-7-4.4-9.5-8.8C.7 8.6 2.4 5 6 5c2.1 0 3.5 1.2 4.5 2.6C11.5 6.2 12.9 5 15 5c3.6 0 5.3 3.6 3.5 7.2C19 16.6 12 21 12 21Z"/>
        </svg>
      </button>
      <a class="tag-card-link" href="adopt.html#${pet.id}" aria-label="View ${pet.name}'s profile">
        <img class="tag-photo" src="${pet.image}" alt="${pet.name}, a ${pet.age} old ${pet.breed}" loading="lazy" onerror="this.onerror=null;this.src='${fallback}'" />
        <div class="tag-body">
          <div class="tag-top-row">
            <span class="tag-name">${pet.name}</span>
            <span class="tag-id">${pet.id}</span>
          </div>
          <div class="tag-meta">${pet.species} · ${pet.breed} · ${pet.age} · ${pet.size}</div>
          <div class="trait-row">${traits}</div>
          <p class="tag-blurb">${pet.blurb}</p>
        </div>
      </a>
    </article>`;
}

function initFavoriteButtons(root) {
  (root || document).querySelectorAll(".fav-btn").forEach((btn) => {
    if (btn.dataset.bound) return;
    btn.dataset.bound = "1";
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const id = btn.dataset.favId;
      const nowOn = toggleFavorite(id, btn);
      if (nowOn) spawnHeartBurst(btn);
    });
  });
}

function spawnHeartBurst(el) {
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const rect = el.getBoundingClientRect();
  for (let i = 0; i < 6; i++) {
    const s = document.createElement("span");
    s.className = "heart-particle";
    s.textContent = "♥";
    s.style.left = rect.left + rect.width / 2 + "px";
    s.style.top = rect.top + "px";
    s.style.setProperty("--dx", (Math.random() - 0.5) * 80 + "px");
    s.style.setProperty("--dy", -(40 + Math.random() * 60) + "px");
    s.style.setProperty("--delay", i * 40 + "ms");
    document.body.appendChild(s);
    setTimeout(() => s.remove(), 900);
  }
}

/* Live shelter ticker */
function initShelterTicker() {
  const el = document.getElementById("shelter-ticker");
  if (!el) return;
  const items = [
    "SOS team responded to a injured indie near NH-24 — stable",
    "Marmalade’s adoption inquiry filed this morning",
    "3 foster homes opened capacity for kittens this week",
    "Partner clinic free vaccine day — Saturday 10am–2pm",
    "Bramble completed behavioural assessment — ready to meet",
    "Donation of surgical kits received — thank you, donors",
    "Volunteer transport run to Noida clinic completed",
    "New intake: beagle mix puppy — needs foster this weekend",
  ];
  let i = 0;
  const text = el.querySelector(".ticker-text");
  if (!text) return;
  const cycle = () => {
    text.style.opacity = "0";
    text.style.transform = "translateY(6px)";
    setTimeout(() => {
      text.textContent = items[i % items.length];
      text.style.opacity = "1";
      text.style.transform = "translateY(0)";
      i++;
    }, 280);
  };
  cycle();
  setInterval(cycle, 4200);
}

/* Time-aware greeting on hero */
function initTimeGreeting() {
  const el = document.getElementById("time-greeting");
  if (!el) return;
  const h = new Date().getHours();
  let msg = "Good evening";
  if (h < 12) msg = "Good morning";
  else if (h < 17) msg = "Good afternoon";
  el.textContent = msg + " — the shelter ledger is open.";
}

/* Simulated presence */
function initPresence() {
  const el = document.getElementById("live-presence");
  if (!el) return;
  const base = 4 + Math.floor(Math.random() * 9);
  const tick = () => {
    const n = Math.max(2, base + Math.floor(Math.random() * 5) - 2);
    el.innerHTML = `<span class="presence-dot"></span> ${n} people browsing animals right now`;
  };
  tick();
  setInterval(tick, 8000);
}

/* Dark mode */
function initThemeToggle() {
  const saved = localStorage.getItem("petme_theme");
  if (saved === "dark") document.documentElement.setAttribute("data-theme", "dark");

  let btn = document.getElementById("theme-toggle");
  if (!btn) {
    const cta = document.querySelector(".nav-cta");
    if (!cta) return;
    btn = document.createElement("button");
    btn.type = "button";
    btn.id = "theme-toggle";
    btn.className = "theme-toggle";
    btn.setAttribute("aria-label", "Toggle dark mode");
    btn.innerHTML = `
      <svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">
        <circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>
      </svg>
      <svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">
        <path d="M21 14.5A8.5 8.5 0 1 1 9.5 3 7 7 0 0 0 21 14.5Z"/>
      </svg>`;
    cta.prepend(btn);
  }

  // Avoid double-binding when auth.js already wired the button
  if (btn.dataset.bound === "1") return;
  btn.dataset.bound = "1";

  const sync = () => {
    const dark = document.documentElement.getAttribute("data-theme") === "dark";
    btn.setAttribute("aria-pressed", String(dark));
    btn.title = dark ? "Switch to light mode" : "Switch to dark mode";
  };
  sync();
  btn.addEventListener("click", () => {
    const dark = document.documentElement.getAttribute("data-theme") === "dark";
    if (dark) {
      document.documentElement.removeAttribute("data-theme");
      localStorage.setItem("petme_theme", "light");
    } else {
      document.documentElement.setAttribute("data-theme", "dark");
      localStorage.setItem("petme_theme", "dark");
    }
    sync();
  });
}

/* Floating SOS FAB */
function initSosFab() {
  if (document.getElementById("sos-fab")) return;
  if (location.pathname.endsWith("sos-report.html")) return;
  const a = document.createElement("a");
  a.id = "sos-fab";
  a.href = "sos-report.html";
  a.className = "sos-fab";
  a.setAttribute("aria-label", "Report a stray animal in distress");
  a.innerHTML = `<span class="sos-fab-pulse"></span><span class="sos-fab-label">SOS</span>`;
  document.body.appendChild(a);
}

/* Confetti celebration on success banners */
const _origShowBanner = typeof showBanner === "function" ? showBanner : null;
function celebrateSuccess() {
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const colors = ["#f0b84a", "#1e3a2f", "#2a7d6e", "#e05535", "#f7f4eb"];
  for (let i = 0; i < 28; i++) {
    const p = document.createElement("span");
    p.className = "confetti-piece";
    p.style.left = Math.random() * 100 + "vw";
    p.style.background = colors[i % colors.length];
    p.style.setProperty("--rot", Math.random() * 360 + "deg");
    p.style.setProperty("--dur", 1.2 + Math.random() * 1.4 + "s");
    p.style.setProperty("--delay", Math.random() * 0.3 + "s");
    document.body.appendChild(p);
    setTimeout(() => p.remove(), 2800);
  }
}

function showBanner(banner, type, message) {
  banner.textContent = message;
  banner.className = `form-banner show ${type}`;
  banner.scrollIntoView({ behavior: "smooth", block: "nearest" });
  if (type === "success") celebrateSuccess();
}

document.addEventListener("DOMContentLoaded", () => {
  initFavoriteButtons(document);
  initShelterTicker();
  initTimeGreeting();
  initPresence();
  initThemeToggle();
  ensureNavControls();
  setTimeout(ensureNavControls, 50);
  initSosFab();
  // Re-bind favorites after dynamic grids render
  setTimeout(() => initFavoriteButtons(document), 100);
});

/* Mutation observer for dynamically rendered pet grids */
if (typeof MutationObserver !== "undefined") {
  const mo = new MutationObserver((mutations) => {
    for (const m of mutations) {
      if (m.addedNodes.length) initFavoriteButtons(document);
    }
  });
  document.addEventListener("DOMContentLoaded", () => {
    const targets = [document.getElementById("pet-grid"), document.getElementById("featured-pets")].filter(Boolean);
    targets.forEach((t) => mo.observe(t, { childList: true, subtree: true }));
  });
}


/* Ensure theme + sign-in + SOS always present even if something else rewrote nav */
function ensureNavControls() {
  const cta = document.querySelector(".nav-cta");
  if (!cta) return;
  if (!document.getElementById("theme-toggle")) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.id = "theme-toggle";
    btn.className = "theme-toggle";
    btn.setAttribute("aria-label", "Toggle dark mode");
    btn.innerHTML = `
      <svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">
        <circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>
      </svg>
      <svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">
        <path d="M21 14.5A8.5 8.5 0 1 1 9.5 3 7 7 0 0 0 21 14.5Z"/>
      </svg>`;
    cta.insertBefore(btn, cta.firstChild);
  }
  if (typeof initThemeToggle === "function") initThemeToggle();
}
