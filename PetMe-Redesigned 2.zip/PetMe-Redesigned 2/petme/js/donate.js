// ==========================================================================
// Donate — amount, frequency, gateway panels (UPI QR / card / net banking)
// Client-side demo of a real checkout UX. Wire Razorpay/Stripe for live charges.
// ==========================================================================

(function () {
  const amountGrid = document.getElementById("amount-grid");
  const customInput = document.getElementById("custom-amount");
  const freqToggle = document.getElementById("freq-toggle");
  const amountLabel = document.getElementById("donate-amount-label");
  let selectedAmount = 1500;
  let frequency = "once";
  let payMethod = "upi";
  let selectedBank = "";

  function refreshLabel() {
    const suffix = frequency === "monthly" ? "/mo" : "";
    if (amountLabel) amountLabel.textContent = `₹${(selectedAmount || 0).toLocaleString("en-IN")}${suffix}`;
    updateUpiQr();
  }

  function updateUpiQr() {
    const img = document.getElementById("upi-qr");
    if (!img) return;
    const am = Math.max(1, selectedAmount || 1);
    // UPI deep link — scanners open GPay/PhonePe/etc.
    const payload = `upi://pay?pa=Anam607050@okaxis&pn=PetMe%20Animal%20Shelter&am=${am.toFixed(2)}&cu=INR&tn=PetMe%20Donation`;
    img.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&margin=8&data=${encodeURIComponent(payload)}`;
    img.alt = `UPI QR for ₹${am.toLocaleString("en-IN")} to PetMe`;
  }

  if (amountGrid) {
    amountGrid.querySelectorAll(".amount-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        amountGrid.querySelectorAll(".amount-btn").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        if (btn.dataset.amount === "custom") {
          customInput.style.display = "block";
          customInput.focus();
          selectedAmount = parseInt(customInput.value, 10) || 0;
        } else {
          customInput.style.display = "none";
          selectedAmount = parseInt(btn.dataset.amount, 10);
        }
        refreshLabel();
      });
    });
  }

  if (customInput) {
    customInput.addEventListener("input", () => {
      selectedAmount = parseInt(customInput.value, 10) || 0;
      refreshLabel();
    });
  }

  if (freqToggle) {
    freqToggle.querySelectorAll("button").forEach((btn) => {
      btn.addEventListener("click", () => {
        freqToggle.querySelectorAll("button").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        frequency = btn.dataset.freq;
        refreshLabel();
      });
    });
  }

  /* ---- Method switch ---- */
  const payMethods = document.getElementById("pay-methods");
  function showPanel(method) {
    payMethod = method;
    document.querySelectorAll(".pay-panel").forEach((p) => {
      const on = p.dataset.panel === method;
      p.hidden = !on;
      p.classList.toggle("active", on);
    });
  }
  if (payMethods) {
    payMethods.querySelectorAll(".pay-method").forEach((btn) => {
      btn.addEventListener("click", () => {
        payMethods.querySelectorAll(".pay-method").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        showPanel(btn.dataset.method);
      });
    });
  }

  /* ---- Bank grid ---- */
  const bankGrid = document.getElementById("bank-grid");
  const bankOther = document.getElementById("bank-other");
  if (bankGrid) {
    bankGrid.querySelectorAll(".bank-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        bankGrid.querySelectorAll(".bank-btn").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        selectedBank = btn.dataset.bank;
        if (bankOther) bankOther.value = "";
      });
    });
  }
  if (bankOther) {
    bankOther.addEventListener("change", () => {
      if (bankOther.value) {
        selectedBank = bankOther.value;
        if (bankGrid) bankGrid.querySelectorAll(".bank-btn").forEach((b) => b.classList.remove("active"));
      }
    });
  }

  /* ---- Card helpers ---- */
  const cardNumber = document.getElementById("card-number");
  if (cardNumber) {
    cardNumber.addEventListener("input", () => {
      let v = cardNumber.value.replace(/\D/g, "").slice(0, 19);
      cardNumber.value = v.replace(/(\d{4})(?=\d)/g, "$1 ").trim();
    });
  }
  const cardExpiry = document.getElementById("card-expiry");
  if (cardExpiry) {
    cardExpiry.addEventListener("input", () => {
      let v = cardExpiry.value.replace(/\D/g, "").slice(0, 4);
      if (v.length >= 3) v = v.slice(0, 2) + "/" + v.slice(2);
      cardExpiry.value = v;
    });
  }

  function luhnOk(num) {
    const digits = num.replace(/\D/g, "");
    if (digits.length < 13 || digits.length > 19) return false;
    let sum = 0, alt = false;
    for (let i = digits.length - 1; i >= 0; i--) {
      let n = parseInt(digits[i], 10);
      if (alt) { n *= 2; if (n > 9) n -= 9; }
      sum += n;
      alt = !alt;
    }
    return sum % 10 === 0;
  }

  function expiryOk(mmYY) {
    const m = mmYY.match(/^(\d{2})\/(\d{2})$/);
    if (!m) return false;
    const month = parseInt(m[1], 10);
    const year = 2000 + parseInt(m[2], 10);
    if (month < 1 || month > 12) return false;
    const now = new Date();
    const exp = new Date(year, month); // first day of next month
    return exp > now;
  }

  function upiOk(id) {
    return /^[\w.\-]{2,256}@[a-zA-Z]{2,64}$/.test((id || "").trim());
  }

  /* ---- Submit ---- */
  const donateForm = document.getElementById("donate-form");
  const donateBanner = document.getElementById("donate-banner");

  if (donateForm) {
    donateForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const supplies = document.getElementById("donor-supplies");
      if (supplies && supplies.checked) {
        showBanner(donateBanner, "success", "Thanks — a coordinator will email you about in-kind (supplies) donations within 1 business day.");
        return;
      }

      const nameOk = validateField(document.getElementById("donor-name"), isNotEmpty, "Enter your name.");
      const emailOk = validateField(document.getElementById("donor-email"), isEmail, "Enter a valid email.");
      if (selectedAmount <= 0) {
        showBanner(donateBanner, "error", "Choose or enter a donation amount first.");
        return;
      }
      if (!(nameOk && emailOk)) {
        showBanner(donateBanner, "error", "Name and email are required.");
        return;
      }

      // Method-specific validation
      if (payMethod === "upi") {
        const upiField = document.getElementById("upi-id");
        // QR path always allowed; if they typed UPI id, validate it
        if (upiField.value.trim() && !upiOk(upiField.value)) {
          validateField(upiField, upiOk, "Enter a valid UPI ID (e.g. name@okaxis)");
          showBanner(donateBanner, "error", "Check your UPI ID, or scan the QR instead.");
          return;
        }
        validateField(upiField, () => true, "");
      }

      if (payMethod === "card") {
        const num = document.getElementById("card-number");
        const cname = document.getElementById("card-name");
        const exp = document.getElementById("card-expiry");
        const cvv = document.getElementById("card-cvv");
        const nOk = validateField(num, (v) => luhnOk(v), "Invalid card number");
        const nameC = validateField(cname, isNotEmpty, "Name on card is required");
        const eOk = validateField(exp, expiryOk, "Invalid or expired date (MM/YY)");
        const vOk = validateField(cvv, (v) => /^\d{3,4}$/.test(v.trim()), "CVV must be 3–4 digits");
        if (!(nOk && nameC && eOk && vOk)) {
          showBanner(donateBanner, "error", "Please complete all card fields correctly.");
          return;
        }
      }

      if (payMethod === "netbanking") {
        if (!selectedBank) {
          showBanner(donateBanner, "error", "Select your bank to continue.");
          if (bankOther) validateField(bankOther, () => false, "Select a bank");
          return;
        }
        if (bankOther) validateField(bankOther, () => true, "");
      }

      const submitBtn = document.getElementById("donate-submit");
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = payMethod === "netbanking" ? "Connecting to bank…" : "Authorising payment…";
      }

      // Simulated gateway + optional 3DS / bank redirect step
      setTimeout(async () => {
        if (payMethod === "netbanking") {
          showBanner(
            donateBanner,
            "success",
            `Connected to ${selectedBank}. Payment of ₹${selectedAmount.toLocaleString("en-IN")} authorised. Receipt emailed.`
          );
        } else if (payMethod === "card") {
          showBanner(
            donateBanner,
            "success",
            `Card authorised. ₹${selectedAmount.toLocaleString("en-IN")}${frequency === "monthly" ? "/mo" : ""} charged. Receipt emailed.`
          );
        } else {
          const via = document.getElementById("upi-id").value.trim() ? "UPI ID" : "UPI QR";
          showBanner(
            donateBanner,
            "success",
            `UPI payment confirmed via ${via}. ₹${selectedAmount.toLocaleString("en-IN")}${frequency === "monthly" ? "/mo" : ""} received.`
          );
        }
        if (typeof recordDonation === "function" && typeof getSession === "function" && getSession()) {
          recordDonation({ amount: selectedAmount, freq: frequency, method: payMethod, bank: selectedBank || undefined });
        }
        const apiResult = await petmeApi("/api/donations", {
          amount: selectedAmount, frequency, method: payMethod,
          bank: selectedBank || "",
          upiId: payMethod === "upi" ? "Anam607050@okaxis" : "",
          paymentId: `PM-${Date.now()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
          name: document.getElementById("donor-name").value.trim(),
          email: document.getElementById("donor-email").value.trim(),
          anonymous: document.getElementById("donor-anon").checked
        });
        if (!apiResult.ok) console.info("Donation kept as demo/local record; backend unavailable.");
        if (submitBtn) {
          submitBtn.disabled = false;
          refreshLabel();
          submitBtn.innerHTML = `Pay <span id="donate-amount-label">₹${selectedAmount.toLocaleString("en-IN")}${frequency === "monthly" ? "/mo" : ""}</span> securely`;
        }
      }, payMethod === "netbanking" ? 1800 : 1400);
    });
  }

  /* ---- Rehome ---- */
  const rehomeForm = document.getElementById("rehome-form");
  const rehomeBanner = document.getElementById("rehome-banner");
  if (rehomeForm) {
    rehomeForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const checks = [
        validateField(document.getElementById("rehome-pet-name"), isNotEmpty),
        validateField(document.getElementById("rehome-species"), isNotEmpty),
        validateField(document.getElementById("rehome-reason"), isNotEmpty),
        validateField(document.getElementById("rehome-owner-name"), isNotEmpty),
        validateField(document.getElementById("rehome-phone"), isPhone),
      ];
      if (checks.includes(false)) {
        showBanner(rehomeBanner, "error", "A few fields on the intake sheet still need attention.");
        return;
      }
      const result = await petmeApi("/api/rehome", {
        petName: document.getElementById("rehome-pet-name").value.trim(),
        species: document.getElementById("rehome-species").value.trim(),
        reason: document.getElementById("rehome-reason").value.trim(),
        ownerName: document.getElementById("rehome-owner-name").value.trim(),
        phone: document.getElementById("rehome-phone").value.trim()
      });
      showBanner(rehomeBanner, "success", result.ok ? "Intake sheet saved — a coordinator will call within 2 business days." : "Intake sheet captured — a coordinator will call within 2 business days.");
      rehomeForm.querySelector("button[type='submit']").disabled = true;
    });
  }

  updateUpiQr();
})();
