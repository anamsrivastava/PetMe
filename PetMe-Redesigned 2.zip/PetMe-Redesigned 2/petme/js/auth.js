// ==========================================================================
// PetMe — client-side auth (localStorage) + simulated 2FA
// Demo only: passwords stored in plain text for prototype. Not production.
// ==========================================================================

const AUTH_KEY = "petme_users";
const SESSION_KEY = "petme_session";
const PENDING_2FA_KEY = "petme_pending_2fa";

function getUsers() {
  try {
    return JSON.parse(localStorage.getItem(AUTH_KEY) || "[]");
  } catch {
    return [];
  }
}

function saveUsers(users) {
  localStorage.setItem(AUTH_KEY, JSON.stringify(users));
}

function getSession() {
  try {
    return JSON.parse(localStorage.getItem(SESSION_KEY) || "null");
  } catch {
    return null;
  }
}

function setSession(user) {
  const safe = {
    id: user.id,
    name: user.name,
    email: user.email,
    roles: user.roles || [],
    pets: user.pets || [],
    donations: user.donations || [],
  };
  localStorage.setItem(SESSION_KEY, JSON.stringify(safe));
  return safe;
}

function clearSession() {
  localStorage.removeItem(SESSION_KEY);
  localStorage.removeItem(PENDING_2FA_KEY);
}

function generateId() {
  return "u_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

function generateOTP() {
  // Fresh random 6-digit code on every call (never reused)
  return String(Math.floor(100000 + Math.random() * 900000));
}

/**
 * Attempt to deliver OTP to the user's email via backend.
 * Returns Promise<boolean> — true if email was actually sent, false for local demo.
 */
async function deliverOtpEmail(email, otp) {
  try {
    const base = (typeof window !== "undefined" && window.PETME_API_BASE) || "";
    const res = await fetch((base || "") + "/api/send-otp", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, otp }),
    });
    if (!res.ok) return false;
    const data = await res.json().catch(() => ({}));
    return Boolean(data && data.sent);
  } catch {
    return false;
  }
}

/** Register a new account. Returns { ok, error?, user?, otp? } */
function registerUser({ name, email, phone, password, roles }) {
  const users = getUsers();
  const normalized = email.trim().toLowerCase();
  if (users.some((u) => u.email === normalized)) {
    return { ok: false, error: "An account with this email already exists." };
  }
  if (!name || name.trim().length < 2) {
    return { ok: false, error: "Please enter your full name." };
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized)) {
    return { ok: false, error: "Enter a valid email address." };
  }
  if (!password || password.length < 8) {
    return { ok: false, error: "Password must be at least 8 characters." };
  }
  const user = {
    id: generateId(),
    name: name.trim(),
    email: normalized,
    phone: (phone || "").trim(),
    password, // demo only
    roles: roles || ["adopter"],
    pets: [],
    donations: [],
    createdAt: new Date().toISOString(),
  };
  users.push(user);
  saveUsers(users);

  const otp = generateOTP();
  localStorage.setItem(
    PENDING_2FA_KEY,
    JSON.stringify({ email: normalized, otp, purpose: "register", expires: Date.now() + 10 * 60 * 1000 })
  );
  return { ok: true, user, otp };
}

/** Start login: validate credentials, issue OTP. Does not create session yet. */
function startLogin(email, password) {
  const users = getUsers();
  const normalized = email.trim().toLowerCase();
  const user = users.find((u) => u.email === normalized);
  if (!user || user.password !== password) {
    return { ok: false, error: "Invalid email or password." };
  }
  const otp = generateOTP();
  localStorage.setItem(
    PENDING_2FA_KEY,
    JSON.stringify({ email: normalized, otp, purpose: "login", expires: Date.now() + 10 * 60 * 1000 })
  );
  return { ok: true, otp, email: normalized };
}

/** Verify OTP and create session */
function verify2FA(code) {
  let pending;
  try {
    pending = JSON.parse(localStorage.getItem(PENDING_2FA_KEY) || "null");
  } catch {
    pending = null;
  }
  if (!pending || !pending.otp) {
    return { ok: false, error: "No verification in progress. Please start again." };
  }
  if (Date.now() > pending.expires) {
    localStorage.removeItem(PENDING_2FA_KEY);
    return { ok: false, error: "Code expired. Please request a new one." };
  }
  if (String(code).trim() !== String(pending.otp)) {
    return { ok: false, error: "Incorrect code. Check and try again." };
  }
  const users = getUsers();
  const user = users.find((u) => u.email === pending.email);
  if (!user) {
    return { ok: false, error: "Account not found." };
  }
  localStorage.removeItem(PENDING_2FA_KEY);
  setSession(user);
  return { ok: true, user };
}

function updateCurrentUser(patch) {
  const session = getSession();
  if (!session) return null;
  const users = getUsers();
  const idx = users.findIndex((u) => u.id === session.id);
  if (idx === -1) return null;
  users[idx] = { ...users[idx], ...patch };
  saveUsers(users);
  return setSession(users[idx]);
}

function addPetToUser(pet) {
  const session = getSession();
  if (!session) return { ok: false, error: "Please sign in first." };
  const pets = [...(session.pets || []), { ...pet, id: "pet_" + Date.now().toString(36) }];
  updateCurrentUser({ pets });
  return { ok: true, pets };
}

function recordDonation(donation) {
  const session = getSession();
  if (!session) return { ok: false };
  const donations = [...(session.donations || []), { ...donation, id: "don_" + Date.now().toString(36), at: new Date().toISOString() }];
  updateCurrentUser({ donations });
  return { ok: true };
}

/** Theme toggle button markup */
function themeToggleHtml() {
  return (
    '<button type="button" id="theme-toggle" class="theme-toggle" aria-label="Toggle dark mode" title="Switch theme">' +
      '<svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">' +
        '<circle cx="12" cy="12" r="4"/>' +
        '<path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>' +
      '</svg>' +
      '<svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">' +
        '<path d="M21 14.5A8.5 8.5 0 1 1 9.5 3 7 7 0 0 0 21 14.5Z"/>' +
      '</svg>' +
    '</button>'
  );
}

function bindThemeToggle(btn) {
  if (!btn || btn.dataset.bound === "1") return;
  btn.dataset.bound = "1";
  const sync = () => {
    const dark = document.documentElement.getAttribute("data-theme") === "dark";
    btn.setAttribute("aria-pressed", String(dark));
    btn.title = dark ? "Switch to light mode" : "Switch to dark mode";
  };
  sync();
  btn.addEventListener("click", () => {
    const dark = document.documentElement.getAttribute("data-theme") === "dark";
    if (dark) {
      document.documentElement.removeAttribute("data-theme");
      localStorage.setItem("petme_theme", "light");
    } else {
      document.documentElement.setAttribute("data-theme", "dark");
      localStorage.setItem("petme_theme", "dark");
    }
    sync();
  });
}

/**
 * Nav CTA always shows: [Theme] [Sign in | Account] [Report a Stray]
 * on every page.
 */
function initAuthNav() {
  let cta = document.querySelector(".nav-cta");
  if (!cta) {
    const nav = document.querySelector("nav.nav");
    if (!nav) return;
    cta = document.createElement("div");
    cta.className = "nav-cta";
    nav.appendChild(cta);
  }

  const session = getSession();
  let accountHtml;
  if (session) {
    accountHtml =
      '<a href="profile.html" class="btn btn-ghost nav-account" aria-label="Your account">' +
        '<span class="nav-avatar" aria-hidden="true">' +
          session.name.charAt(0).toUpperCase() +
        "</span>" +
        escapeHtml(session.name.split(" ")[0]) +
      "</a>";
  } else {
    accountHtml = '<a href="login.html" class="btn btn-ghost">Sign in</a>';
  }

  cta.innerHTML =
    themeToggleHtml() +
    accountHtml +
    '<a href="sos-report.html" class="btn btn-urgent">Report a Stray</a>';

  bindThemeToggle(document.getElementById("theme-toggle"));
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

document.addEventListener("DOMContentLoaded", initAuthNav);
