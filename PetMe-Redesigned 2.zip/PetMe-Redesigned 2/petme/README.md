# PetMe 🐾 — Shelter & Adoption Platform

PetMe is a polished shelter/adoption web app with an intake-ledger visual style, adoption discovery, donations, healthcare, SOS reporting, volunteering, rehoming and user accounts.

## What's enhanced
- Added a **Python Flask backend** that runs directly from VS Code.
- Added REST APIs for adoption inquiries, donations, volunteer applications, SOS reports, rehoming, contact messages and newsletter subscriptions.
- Added **Amazon DynamoDB support** using the college AWS account when AWS credentials are configured.
- Added an automatic **local JSON fallback** so the project works without AWS credentials.
- Added `/api/health` and `/api/admin/summary` endpoints for quick backend checks.
- Frontend forms now send their submissions to the backend while retaining the original user-friendly demo behaviour.
- Added clean environment-variable configuration; AWS secrets are never placed in frontend code.

## Run in VS Code
```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r backend\requirements.txt
python backend\app.py
```

Open **http://127.0.0.1:5000**.

You no longer need Live Server for the complete frontend + backend experience.

## Connect the college AWS account
1. Copy `backend/.env.example` to `backend/.env`.
2. Enter the AWS credentials/role details provided by your college.
3. Keep `backend/.env` private.
4. Run `python backend/app.py` again.

PetMe uses Amazon DynamoDB with on-demand billing and automatically creates its application tables. This is intended for a college/free-tier-style setup; follow the limits and policies of the AWS account provided by your college.

## Pages
- `index.html` — Home
- `adopt.html` — Browse + filter + adoption inquiry
- `donate.html` — Donation + rehoming intake
- `healthcare.html` — Healthcare services
- `sos-report.html` — Stray animal emergency report
- `volunteer.html` — Volunteer signup
- `foster.html` — Foster guide
- `faq.html` — Adoption FAQ
- `contact.html` — Contact form
- `about.html` — About PetMe
- `register.html` / `login.html` — Account flow
- `profile.html` — User profile

## Important
The existing account and payment screens are still **demo/prototype flows**. Do not use the project to process real card payments or store real payment-card data. For a production deployment, use a compliant payment provider and a proper authentication service.

See `backend/README.md` for the AWS/backend setup details.
