# PetMe — Quick VS Code Run

### Windows
```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r backend\requirements.txt
python backend\app.py
```

Then open: **http://127.0.0.1:5000**

### AWS
Copy `backend/.env.example` → `backend/.env` and enter the college-provided AWS credentials. The backend will use Amazon DynamoDB automatically. Do not put AWS credentials in frontend JavaScript.
