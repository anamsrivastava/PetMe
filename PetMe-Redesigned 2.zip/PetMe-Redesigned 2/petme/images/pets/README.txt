HOW TO USE YOUR OWN PET PHOTOS
==============================

1. Put image files in this folder, e.g.:
     bramble.jpg
     marmalade.jpg
     kavi.jpg

2. In js/pets-data.js, set the "image" field to a path relative to the HTML page:

     image: "images/pets/bramble.jpg"

   Or keep a full web URL:

     image: "https://example.com/my-dog.jpg"

3. Save the file and refresh the browser (Live Server).

Tips:
- Prefer square or landscape photos (about 700px wide works well).
- Formats: .jpg, .jpeg, .png, .webp
- File names should have no spaces (use hyphens: my-dog.jpg)
