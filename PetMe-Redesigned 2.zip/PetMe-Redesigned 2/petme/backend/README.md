# PetMe Backend + AWS Setup

## 1. Run locally in VS Code
From the `petme` folder:

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r backend\requirements.txt
python backend\app.py
```

Open **http://127.0.0.1:5000**.

The backend automatically serves the PetMe frontend, so you do not need Live Server.

## 2. Connect the college AWS account
1. Copy `backend/.env.example` to `backend/.env`.
2. Put the AWS credentials provided by your college in `.env`.
3. Keep the `.env` file private and never upload it to GitHub.
4. Start the backend again.

When AWS credentials are available, PetMe uses **Amazon DynamoDB** with on-demand billing (`PAY_PER_REQUEST`). The app creates these tables automatically:

- `petme-users`
- `petme-adoptions`
- `petme-donations`
- `petme-volunteers`
- `petme-sos-reports`
- `petme-rehome`
- `petme-messages`
- `petme-newsletter`

If AWS credentials are not configured, all submissions are stored in `backend/data/petme-data.json`, so the project still works in a normal VS Code setup.

## 3. API test
Open `http://127.0.0.1:5000/api/health`.

It reports whether the app is using `aws-dynamodb` or `local-json` storage.

## 4. Important AWS note
Use the college-provided AWS IAM credentials/role and stay inside the college's allowed AWS budget/free-tier rules. Do not paste credentials into JavaScript, HTML, or GitHub.


## Payment database
Donation records are saved in `backend/data/petme-data.json` when AWS credentials are not configured. When AWS credentials are configured, they are saved to DynamoDB table `petme-donations`. `GET /api/donations` returns saved donation records.
