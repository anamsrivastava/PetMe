"""PetMe backend.

Runs locally in VS Code and can use Amazon DynamoDB/S3 when AWS credentials are configured.
If AWS is not configured, the app falls back to a small local JSON datastore so the project
still works without cloud credentials.
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

try:
    import boto3
    from botocore.exceptions import BotoCoreError, ClientError
except ImportError:  # pragma: no cover
    boto3 = None
    BotoCoreError = ClientError = Exception

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "backend" / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
LOCAL_FILE = DATA_DIR / "petme-data.json"

AWS_REGION = os.getenv("AWS_REGION", "ap-south-1")
TABLE_PREFIX = os.getenv("PETME_TABLE_PREFIX", "petme")
S3_BUCKET = os.getenv("PETME_S3_BUCKET", "").strip()
USE_AWS = bool(os.getenv("AWS_ACCESS_KEY_ID") and os.getenv("AWS_SECRET_ACCESS_KEY") and boto3)

app = Flask(__name__, static_folder=str(ROOT), static_url_path="")
CORS(app, resources={r"/api/*": {"origins": "*"}})

RESOURCE_TABLES = {
    "users": f"{TABLE_PREFIX}-users",
    "adoptions": f"{TABLE_PREFIX}-adoptions",
    "donations": f"{TABLE_PREFIX}-donations",
    "volunteers": f"{TABLE_PREFIX}-volunteers",
    "sos_reports": f"{TABLE_PREFIX}-sos-reports",
    "rehome": f"{TABLE_PREFIX}-rehome",
    "messages": f"{TABLE_PREFIX}-messages",
    "newsletter": f"{TABLE_PREFIX}-newsletter",
}


def now():
    return datetime.now(timezone.utc).isoformat()


def load_local():
    if not LOCAL_FILE.exists():
        data = {k: [] for k in RESOURCE_TABLES}
        LOCAL_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return data
    try:
        return json.loads(LOCAL_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {k: [] for k in RESOURCE_TABLES}


def save_local(data):
    LOCAL_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


class Store:
    def __init__(self):
        self.dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION) if USE_AWS else None
        self.s3 = boto3.client("s3", region_name=AWS_REGION) if USE_AWS and S3_BUCKET else None
        if self.dynamodb:
            self.ensure_tables()

    def ensure_tables(self):
        for table_name in RESOURCE_TABLES.values():
            try:
                self.dynamodb.Table(table_name).load()
            except ClientError as exc:
                if exc.response.get("Error", {}).get("Code") != "ResourceNotFoundException":
                    raise
                self.dynamodb.create_table(
                    TableName=table_name,
                    KeySchema=[{"AttributeName": "id", "KeyType": "HASH"}],
                    AttributeDefinitions=[{"AttributeName": "id", "AttributeType": "S"}],
                    BillingMode="PAY_PER_REQUEST",
                )

    def put(self, resource, item):
        if self.dynamodb:
            self.dynamodb.Table(RESOURCE_TABLES[resource]).put_item(Item=item)
        else:
            data = load_local()
            data[resource].append(item)
            save_local(data)
        return item

    def scan(self, resource, limit=100):
        if self.dynamodb:
            result = self.dynamodb.Table(RESOURCE_TABLES[resource]).scan(Limit=limit)
            return result.get("Items", [])
        return load_local().get(resource, [])[-limit:][::-1]


store = Store()


def clean(value, max_len=2000):
    if value is None:
        return ""
    return str(value).strip()[:max_len]


def create_record(resource, payload):
    item = {"id": str(uuid.uuid4()), "createdAt": now(), **payload}
    return store.put(resource, item)


@app.get("/api/health")
def health():
    return jsonify({"ok": True, "service": "PetMe API", "storage": "aws-dynamodb" if USE_AWS else "local-json", "region": AWS_REGION})


def _send_otp_email(to_email: str, otp: str) -> bool:
    """Send OTP via SMTP when PETME_SMTP_* env vars are set. Returns True if sent."""
    host = os.getenv("PETME_SMTP_HOST", "").strip()
    user = os.getenv("PETME_SMTP_USER", "").strip()
    password = os.getenv("PETME_SMTP_PASS", "").strip()
    from_addr = os.getenv("PETME_SMTP_FROM", user).strip()
    port = int(os.getenv("PETME_SMTP_PORT", "587") or "587")
    if not host or not user or not password or not to_email:
        return False
    try:
        import smtplib
        from email.message import EmailMessage

        msg = EmailMessage()
        msg["Subject"] = f"Your PetMe verification code: {otp}"
        msg["From"] = from_addr
        msg["To"] = to_email
        msg.set_content(
            f"Your PetMe one-time verification code is: {otp}\n\n"
            f"This code expires in 10 minutes and is unique to this sign-in attempt.\n"
            f"If you did not request this, you can ignore this email.\n\n"
            f"— PetMe"
        )
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.starttls()
            smtp.login(user, password)
            smtp.send_message(msg)
        return True
    except Exception:
        return False


@app.post("/api/send-otp")
def send_otp():
    """Email a one-time verification code. Code must be supplied by the client
    (already generated uniquely per attempt). When SMTP is not configured the
    endpoint still succeeds so the UI can fall back to local demo display.
    """
    data = request.get_json(silent=True) or {}
    email = clean(data.get("email"), 320).lower()
    otp = clean(data.get("otp"), 12)
    if not email or not otp or not otp.isdigit() or len(otp) != 6:
        return jsonify({"ok": False, "error": "Valid email and 6-digit otp required."}), 400
    sent = _send_otp_email(email, otp)
    return jsonify({"ok": True, "sent": sent, "email": email})


@app.post("/api/users")
def users():
    data = request.get_json(silent=True) or {}
    if not clean(data.get("name")) or not clean(data.get("email")):
        return jsonify({"ok": False, "error": "Name and email are required."}), 400
    record = create_record("users", {
        "name": clean(data.get("name")), "email": clean(data.get("email")),
        "phone": clean(data.get("phone")), "roles": data.get("roles", []),
        "status": "active"
    })
    return jsonify({"ok": True, "id": record["id"]}), 201

@app.post("/api/adoptions")
def adoption():
    data = request.get_json(silent=True) or {}
    required = ["petId", "petName", "name", "email", "phone"]
    if any(not clean(data.get(k)) for k in required):
        return jsonify({"ok": False, "error": "Please complete all required adoption fields."}), 400
    record = create_record("adoptions", {
        "petId": clean(data.get("petId")), "petName": clean(data.get("petName")),
        "name": clean(data.get("name")), "email": clean(data.get("email")),
        "phone": clean(data.get("phone")), "status": "new",
    })
    return jsonify({"ok": True, "message": "Adoption inquiry saved to PetMe backend.", "id": record["id"]}), 201


@app.post("/api/donations")
def donation():
    data = request.get_json(silent=True) or {}
    try:
        amount = float(data.get("amount", 0))
    except (TypeError, ValueError):
        amount = 0
    if amount <= 0:
        return jsonify({"ok": False, "error": "Donation amount must be greater than zero."}), 400
    method = clean(data.get("method"), 30) or "upi"
    payment_id = clean(data.get("paymentId"), 100) or f"PM-{uuid.uuid4().hex[:12].upper()}"
    record = create_record("donations", {
        "paymentId": payment_id,
        "amount": amount,
        "currency": "INR",
        "frequency": clean(data.get("frequency"), 30) or "once",
        "method": method,
        "upiId": clean(data.get("upiId"), 256),
        "bank": clean(data.get("bank"), 100),
        "name": clean(data.get("name")),
        "email": clean(data.get("email")),
        "anonymous": bool(data.get("anonymous")),
        "status": "initiated" if method == "upi" else "demo-recorded",
    })
    return jsonify({"ok": True, "message": "Donation record saved.", "id": record["id"], "paymentId": payment_id}), 201

@app.get("/api/donations")
def donations():
    return jsonify({"ok": True, "donations": store.scan("donations", 1000)})


@app.post("/api/volunteers")
def volunteer():
    data = request.get_json(silent=True) or {}
    if not clean(data.get("name")) or not clean(data.get("email")):
        return jsonify({"ok": False, "error": "Name and email are required."}), 400
    record = create_record("volunteers", {
        "name": clean(data.get("name")), "email": clean(data.get("email")),
        "phone": clean(data.get("phone")), "age": clean(data.get("age")),
        "availability": clean(data.get("availability")), "roles": data.get("roles", []),
        "status": "new",
    })
    return jsonify({"ok": True, "message": "Volunteer application saved.", "id": record["id"]}), 201


@app.post("/api/sos")
def sos():
    data = request.get_json(silent=True) or {}
    if not clean(data.get("description")) or not clean(data.get("location")):
        return jsonify({"ok": False, "error": "Location and description are required."}), 400
    record = create_record("sos_reports", {
        "name": clean(data.get("name")), "phone": clean(data.get("phone")),
        "location": clean(data.get("location")), "species": clean(data.get("species")),
        "urgency": clean(data.get("urgency"), 30), "description": clean(data.get("description")),
        "photoUrl": clean(data.get("photoUrl")), "status": "new",
    })
    return jsonify({"ok": True, "message": "SOS report saved and queued for review.", "id": record["id"]}), 201


@app.post("/api/rehome")
def rehome():
    data = request.get_json(silent=True) or {}
    if not clean(data.get("ownerName")) or not clean(data.get("petName")):
        return jsonify({"ok": False, "error": "Owner name and pet name are required."}), 400
    record = create_record("rehome", {
        "ownerName": clean(data.get("ownerName")), "petName": clean(data.get("petName")),
        "phone": clean(data.get("phone")), "species": clean(data.get("species")),
        "reason": clean(data.get("reason")), "status": "new",
    })
    return jsonify({"ok": True, "message": "Rehoming intake saved.", "id": record["id"]}), 201


@app.post("/api/contact")
def contact():
    data = request.get_json(silent=True) or {}
    if not clean(data.get("name")) or not clean(data.get("email")) or not clean(data.get("message")):
        return jsonify({"ok": False, "error": "Name, email and message are required."}), 400
    record = create_record("messages", {
        "name": clean(data.get("name")), "email": clean(data.get("email")),
        "topic": clean(data.get("topic")), "message": clean(data.get("message")), "status": "new",
    })
    return jsonify({"ok": True, "message": "Message saved to the PetMe backend.", "id": record["id"]}), 201


@app.post("/api/newsletter")
def newsletter():
    data = request.get_json(silent=True) or {}
    email = clean(data.get("email"))
    if "@" not in email:
        return jsonify({"ok": False, "error": "Enter a valid email."}), 400
    record = create_record("newsletter", {"email": email})
    return jsonify({"ok": True, "message": "Subscribed successfully.", "id": record["id"]}), 201


@app.get("/api/admin/summary")
def summary():
    return jsonify({resource: len(store.scan(resource, 1000)) for resource in RESOURCE_TABLES})


@app.get("/")
def index():
    return send_from_directory(ROOT, "index.html")


@app.get("/<path:path>")
def frontend(path):
    target = ROOT / path
    if target.is_file():
        return send_from_directory(ROOT, path)
    return send_from_directory(ROOT, "index.html")


if __name__ == "__main__":
    print("🐾 PetMe running at http://127.0.0.1:5000")
    print("Storage:", "Amazon DynamoDB" if USE_AWS else "local JSON fallback")
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=True)
